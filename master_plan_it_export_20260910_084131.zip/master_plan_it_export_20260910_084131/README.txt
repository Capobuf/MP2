MASTER PLAN IT - ESPORTAZIONE DATI

Sito: budget.nirolabel.it
Data esportazione: 2026-09-10T08:41:31.515638

Contenuto:
- json/all_data.json: tutti i record, raggruppati per DocType.
- json/*.json: un file per ogni DocType.
- csv/*.csv: una tabella per ogni DocType; le child table sono file separati.
- schema.json: descrizione di campi e colonne.
- manifest.json: conteggi, checksum e metadati dell'esportazione.
- attachments_manifest.csv: indice degli allegati e stato della copia.
- attachments/: copie dei file locali pubblici e privati collegati ai dati MPIT.

Conteggi:
- MPIT Year: 3
- MPIT Cost Center: 10
- MPIT Vendor: 30
- MPIT Project: 10
- MPIT Contract: 19
- MPIT Contract Term: 22
- MPIT Expense: 35
- MPIT Expense Row: 41
- MPIT Settings: 1

Nota di sicurezza: l'archivio può contenere dati personali, economici e allegati privati.
Conservarlo e trasferirlo con le stesse protezioni applicate al sistema Frappe.
